import { Component,ViewChild, OnInit } from '@angular/core';
import { ChartType, ChartOptions, ChartLegendLabelOptions, ChartDataSets } from 'chart.js';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Location } from '@angular/common';

@Component({
  selector: 'app-dsr',
  templateUrl: './dsr.component.html',
  styleUrls: ['./dsr.component.css']
})
export class DsrComponent implements OnInit {

  Url: string = 'https://api.plint.in';
  headers = new HttpHeaders().set('Content-Type', 'application/json')
  .append('Authorization', 'Bearer ' + window.sessionStorage.getItem('access_token'));

  user_id: string;
  items: Array<any>;
  ele: ChartDataSets[] = [];
  Data1 = [];
  
  barChartOptions: ChartOptions = {
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  };
  
  public mostuniqueClients: Label[] = [];
  public mostuniqueClientsData: ChartDataSets[] = [
    {data: []},
    // { 
    //   data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' 
    // }
  ];

  barChartType: ChartType = 'bar';
  barChartLegend = false;
  public barChartPlugins = [];

  constructor(private http: HttpClient, private actRoute: ActivatedRoute, private location: Location) 
  {
    this.user_id = this.actRoute.snapshot.params.user_id;

    
    
  }

  ngOnInit(): void {  
    this.most_meetings_unique_companies();
  }

  most_meetings_unique_companies()
  {
    let API_URL = this.Url+'/dsr/meetings/analytics';
    this.http.get<any>(`${API_URL}`, {headers: this.headers})
    .subscribe((res: any) => {
    // console.log(res.data);
      
    this.Data1 = res.data.top_meetings_by_employees_with_unique_companies;
    console.log(res.data);
    
      for(let i=0; i < this.Data1.length; i++)
      {
        let ele = { data: [] };
        this.mostuniqueClientsData.push(ele);
        this.mostuniqueClients.push(this.Data1[i].name);
        // console.log(this.mostuniqueClients)
      }
      
      for (let j = 0; j < this.Data1.length; j++)  
      {
        // this.mostuniqueClients.push(this.Data1[i].name);

          this.mostuniqueClientsData[j].data.push(this.Data1[j].num_meetings);
      }
     console.log(this.mostuniqueClients, this.mostuniqueClientsData);
    });
  
  }

  
  goBack() {
    this.location.back();
  }
  
  goForward() {
    this.location.forward();
  }

  
}

